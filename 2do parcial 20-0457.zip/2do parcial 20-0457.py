import csv

class Producto:
    def __init__(self, name: str, price: float, discount: float) -> None:
        self.name = name
        self.price = price
        self.discount = discount

    def imprimir_producto(self) -> None:
        print(f"Producto: {self.name}, Precio: {self.price}, Descuento: {self.discount}%")

def buscar_producto(productos, nombre):
    for producto in productos:
        if producto.name == nombre:
            return producto
    return None

def cargar_productos_csv(ruta: str) -> list:
    '''
    Lee los datos de productos desde un archivo CSV y devuelve una lista con los objetos Producto.

    Args:
        ruta (str): La ubicación completa del archivo CSV a leer.

    Returns:
        list: Una lista de objetos Producto, donde cada objeto es un producto cargado desde el CSV.

    Raises:
        FileNotFoundError: Si no se encuentra el archivo CSV en la ruta indicada.
    '''
    try:
        with open(ruta, 'r') as csv_file:
            reader = csv.DictReader(csv_file)
            productos = []
            for row in list(reader):
                try:
                    if float(row["precio"]) < 0:
                        raise ValueError("El precio debe ser un valor positivo.")
                    if float(row["porcentaje_descuento"]) > 100:
                        raise ValueError("El descuento no puede superar el 100%.")
                    if row["nombre_producto"]:
                        productos.append(Producto(row["nombre_producto"], float(row["precio"]), float(row["porcentaje_descuento"])))
                except ValueError as e:
                    print(f"Error al cargar el producto: {e}")
                    continue
            if len(productos) == 0:
                print("No se encontraron productos en el archivo CSV.")
                return
            return productos
    except FileNotFoundError as f:
        print("No se ha encontrado el archivo CSV en la ruta indicada.")

def aplicar_descuento(productos, porcentaje_descuento):
    """Aplica un descuento a los precios de todos los productos.

    Args:
        productos (list): Lista de objetos Producto.
        porcentaje_descuento (float): El porcentaje de descuento a aplicar.
    """

    for producto in productos:
        print(type(producto.price))
        producto.price *= (1 - float(porcentaje_descuento) / 100)

def mostrar_menu():
    print("\n\n\n\nMenú de opciones:")
    print("1. Calcular el precio promedio de los productos")
    print("2. Aplicar descuento a todos los productos")
    print("3. Aplicar descuento individual a un producto")
    print("4. Cargar productos desde un archivo CSV")
    print("5. Buscar un producto por su nombre")
    print("6. Ver todos los productos")
    print("7. Salir")

productos = []
while True:
    mostrar_menu()
    opcion = input("Selecciona una opción: ")

    if opcion == '1':
        if len(productos) == 0:
            print("Primero debes cargar los productos utilizando la opción 4.")
        else:
            print(sum(list(map(lambda x: float(x.price), productos))) / len(productos))
        
    elif opcion == '2':
        descuento = float(input("Introduce el porcentaje de descuento global que deseas aplicar: "))
        aplicar_descuento(productos, descuento)
        print(f"Se ha aplicado un descuento del {descuento}% a todos los productos.")
    elif opcion == '3': 
        for producto in productos:
            producto.price *= (1 - float(producto.discount) / 100)
            print(f"Se aplicó un descuento del {producto.discount}% al producto {producto.name}.")
    elif opcion == '4': 
        ruta = input("Introduce la ruta del archivo CSV a leer: ")
        productos = cargar_productos_csv(ruta)
        if productos:
            for prod in productos:
                prod.imprimir_producto()
            print("Los productos se han cargado exitosamente.")
    elif opcion == '5':  
        nombre_producto = input("Ingresa el nombre del producto que deseas buscar: ")
        producto = buscar_producto(productos, nombre_producto)
        if producto:
            producto.imprimir_producto()
        else:
            print("No se encontró el producto con ese nombre.")
    elif opcion == '6':
        if len(productos) == 0:
            print("Primero debes cargar los productos utilizando la opción 4.")
        for producto in productos:
            producto.imprimir_producto()
    elif opcion == '7':
        print("Saliendo del programa...")
        break
    else:
        print("Opción no válida. Por favor, intenta nuevamente.")
